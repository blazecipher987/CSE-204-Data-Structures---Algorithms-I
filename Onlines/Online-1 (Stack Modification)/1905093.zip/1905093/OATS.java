import java.util.Scanner;

public class OATS<E> {

    private int countA;
    private int countB;
    private int maxSize;
    ArrayImplementation<E> stackA;
    ArrayImplementation<E> stackB;

    OATS(int size, ArrayImplementation st1,ArrayImplementation st2){
        stackA=st1;
        stackA.setDirection(1);
        stackB=st2;
        stackB.setDirection(-1);
        maxSize=size;
        countA=0;
        countB=0;
    }

    E[] arr =(E[]) new Object[maxSize*2];

//    ArrayImplementation<E> stackA = new ArrayImplementation<>(arr,maxSize,1);
//    ArrayImplementation<E> stackB = new ArrayImplementation<>(arr,maxSize,-1);

    public void pushA(E it){

        if(countA+countB>maxSize){
            E[] temp = (E[]) new Object[maxSize*2];

            maxSize=maxSize*2;

            ArrayImplementation<E> tempA = new ArrayImplementation<>(lengthA());
            ArrayImplementation<E> tempB = new ArrayImplementation<>(lengthB());

            while (lengthA()>0){
                tempA.push(stackA.pop());
            }
            while (lengthB()>0){
                tempB.push(stackB.pop());
            }
            arr=temp;
            stackA = new ArrayImplementation<>(arr,lengthA(),1);
            stackB = new ArrayImplementation<>(arr,lengthB(),-1);

            while (tempA.length()>0){
                stackA.push(tempA.pop());
            }
            while (tempB.length()>0){
                stackB.push(tempB.pop());
            }

            E x=  stackA.pop();
            countA--;
        }

        else {
            stackA.push(it);
            countA++;
        }

    }

    public E popA(){
        if(lengthA()>0){
            E x=  stackA.pop();
            countA--;
            return x;
        }
        else {
            System.out.println("Stack A is empty");
            return null;
        }
    }

    public E topValueA(){
        E x = stackA.topValue();
        return x;
    }

    public int lengthA(){
        return countA;
    }

    public void pushB(E it){
        if(countA+countB>maxSize){
            E[] temp = (E[]) new Object[maxSize*2];

            maxSize=maxSize*2;

            ArrayImplementation<E> tempA = new ArrayImplementation<>(lengthA());
            ArrayImplementation<E> tempB = new ArrayImplementation<>(lengthB());

            while (lengthA()>0){
                tempA.push(stackA.pop());
            }
            while (lengthB()>0){
                tempB.push(stackB.pop());
            }
            arr=temp;
            stackA = new ArrayImplementation<>(arr,lengthA(),1);
            stackB = new ArrayImplementation<>(arr,lengthB(),-1);

            while (tempA.length()>0){
                stackA.push(tempA.pop());
            }
            while (tempB.length()>0){
                stackB.push(tempB.pop());
            }

            stackB.push(it);
            countB++;
        }

        else{
            stackB.push(it);
            countB++;
        }
    }

    public E popB(){

        if(lengthB()>0){
            E x=  stackB.pop();
            countB--;
            return x;
        }
        else {
            System.out.println("Stack B is empty");
            return null;
        }

    }

    public E topValueB(){

        E x = stackB.topValue();
        return x;
    }

    public int lengthB(){
        return countB;
    }
}

class tester5{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int x = sc.nextInt();
        OATS<Integer> ar[] = new OATS[x];

       // ArrayImplementation<Integer> stackA = new ArrayImplementation<>(ar,x,1);


    }
}