interface Stack_ADT<E>{
    public void clear();
    public void push(E x);
    public E pop();
    public int length();
    public E topValue();
    public void setDirection(int dir);
}
