import java.util.ArrayList;
import java.util.Scanner;

class Node<E>{
    private E element;
    private Node<E> next;


    Node(E x, Node<E> next){
        element=x;
        this.next = next; }

    Node(Node<E> next){
        this.next = next;
    }
    Node<E> next(){
        return next;
    }
    Node<E> setNext(Node<E> nextVal){
        return next = nextVal;
    }
    E getElement(){
        return element;
    }
    void setElement(E x){
        element=x;
    }
}

public class LinkedListImplementation<E> implements Stack_ADT<E> {

    private Node<E> top;
    private int size;
    private int direction;

    public LinkedListImplementation(){
        top=null;
        size=0;
    }
    public LinkedListImplementation(int size){
        top = null;
        this.size  = 0;
    }

    @Override
    public void clear() {
        top = null;
        size=0;
    }

    @Override
    public void push(E x) {
        top = new Node<>(x,top);
        size++;
    }

    @Override
    public E pop() {
        if(size==0){
            return null;
        }
        size--;
        E x = top.getElement();
        top = top.next();
        return x;
    }

    @Override
    public int length() {
        return size;
    }

    @Override
    public E topValue() {
        if(size>0)
            return top.getElement();
        else
            return null;
    }


    @Override
    public void setDirection(int dir) {
        if(dir!=1 || dir!=1){
            return;
        }
        direction=dir;
    }
}

//class tester2{
//    public static void print(LinkedListImplementation<Integer> ar) {
//        //Array<Integer> a = new Array<>();
//        int[] a = new int[ar.length()];
//        int i = 0;
//        while (ar.length() != 0) {
//            int x = ar.pop();
//            //System.out.println(x);
//            //a.add(x);
//            a[i] = x;
//            i++;
//        }
//        System.out.print("< ");
//        for (i = a.length - 1; i >= 0; i--) {
//            System.out.print(a[i] + " ");
//        }
//        System.out.println(" >");
//        for (i = a.length - 1; i >= 0; i--) {
//            ar.push(a[i]);
//        }
//    }
//
//    public static void main(String[] args) {
//        LinkedListImplementation<Integer> ar = new LinkedListImplementation<>(5);
//        Scanner sc = new Scanner(System.in);
//        int x = sc.nextInt();
//        for (int i = 0; i < x; i++) {
//            int temp = sc.nextInt();
//            ar.push(temp);
//        }
//
//        //print(ar);
//
//
//        int p;
//        int q = -1;
//        while (q != 0 || (q > 0 && q <= 6)) {
//            q = sc.nextInt();
//            p = sc.nextInt();
//
//            if (q == 0) {
//                System.exit(0);
//            }
//            if (q == 1) {
//                ar.clear();
//                System.out.println("< >");
//                System.out.println("-1");
//
//            }
//            if (q == 2) {
//                ar.push(p);
//                print(ar);
//                System.out.println("-1");
//
//            }
//            if (q == 3) {
//                int x1 = ar.pop();
//                print(ar);
//                System.out.println(x1);
//
//            }
//            if (q == 4) {
//                int x1 = ar.length();
//                print(ar);
//                System.out.println(x1);
//
//            }
//            if (q == 5) {
//                int x1 = ar.topValue();
//                print(ar);
//                System.out.println(x1);
//            }
//
//
//        }
//
//
//    }
//}