import java.util.Scanner;

public class commonCodes {

    //Array Implementation printing
//    public static void print(ArrayImplementation<Integer> ar) {
//        int[] a = new int[ar.length()];
//        int i = 0;
//        while (ar.length() != 0) {
//            int x = ar.pop();
//            a[i] = x;
//            i++;
//        }
//        System.out.print("< ");
//        for (i = a.length - 1; i >= 0; i--) {
//            System.out.print(a[i] + " ");
//        }
//        System.out.println(" >");
//        for (i = a.length - 1; i >= 0; i--) {
//            ar.push(a[i]);
//        }
//    }

    //LinkedList Implementation Printing
    public static void print(LinkedListImplementation<Integer> ar) {
        //Array<Integer> a = new Array<>();
        int[] a = new int[ar.length()];
        int i = 0;
        while (ar.length() != 0) {
            int x = ar.pop();
            //System.out.println(x);
            //a.add(x);
            a[i] = x;
            i++;
        }
        System.out.print("< ");
        for (i = a.length - 1; i >= 0; i--) {
            System.out.print(a[i] + " ");
        }
        System.out.println(" >");
        for (i = a.length - 1; i >= 0; i--) {
            ar.push(a[i]);
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int size = sc.nextInt();

        Integer[] a = new Integer[5];
        for (int i = 0; i < 5; i++) {
            a[i]=i;
        }

        //ArrayImplementation<Integer> ar = new ArrayImplementation<>(size);
        //ArrayImplementation<Integer> ar = new ArrayImplementation<>(a,a.length,-1);
        LinkedListImplementation<Integer> ar = new LinkedListImplementation<>(size);

//
        //ar.setDirection(-1);
        //int x = sc.nextInt();
        //System.out.println(ar.length());

        for (int i = 0; i < size; i++) {
            int temp = sc.nextInt();
            ar.push(temp);
        }

        print(ar);
        int p;
        int q = -1;
        while (q != 0 || (q > 0 && q <= 6)) {
            q = sc.nextInt();
            p = sc.nextInt();

            if (q == 0) {
                System.exit(0);
            }
            if (q == 1) {
                ar.clear();
                System.out.println("< >");
                System.out.println("-1");
            }
            if (q == 2) {
                ar.push(p);
                print(ar);
                System.out.println("-1");
            }
            if (q == 3) {
                int x = ar.pop();
                print(ar);
                System.out.println(x);
            }
            if (q == 4) {
                int x = ar.length();
                print(ar);
                System.out.println(x);
            }
            if (q == 5) {
                int x = ar.topValue();
                print(ar);
                System.out.println(x); }
        }
    }
}
