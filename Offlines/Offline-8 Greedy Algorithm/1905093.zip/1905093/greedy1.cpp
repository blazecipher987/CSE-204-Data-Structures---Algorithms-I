#include<iostream>
#include<algorithm>
using namespace std;

//Function to solve the given problem
int solve(int *ar,  int n, int k){
    long long int sum  = 0;
    for(int i =0 ;i<n ; i++ ){
        sum += ((i/k)+1)*ar[i]; //The (i/k) term will have effect only when n>k
    }
    return sum;
}

int main(){
    int n,k;
    long long int ans;
    cin>>n>>k;
    int *plantCost = new int[n];
    
    for(int i = 0; i<n ; i++){
        cin>>plantCost[i];}

    //To greedily solve our problem we sort flower prices on decending
    //order and take the grater priced ones first,which leads to an
    //optimal solution
    sort(plantCost, plantCost+n,greater<int>());

    ans = solve(plantCost, n, k);

    
    cout<<ans<<endl;
}