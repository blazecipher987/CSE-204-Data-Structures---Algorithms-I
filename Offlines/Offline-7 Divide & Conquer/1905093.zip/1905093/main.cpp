#include<iostream>
#include<vector>
#include<ctime>
#include<algorithm>
#include <iomanip>
#include <chrono>
#include<fstream>
using namespace std;
using namespace chrono;
using namespace std;


void merge(int arr[], int low, int mid, int high) {
  
//Create two subarrays to help with sorting
  int n1 = mid - low + 1;
  int n2 = high - mid;

  int L[n1], M[n2];

  for (int i = 0; i < n1; i++)
    L[i] = arr[low + i];
  for (int j = 0; j < n2; j++)
    M[j] = arr[mid + 1 + j];

  // Maintain current index of sub-arrays and main array
  int i, j, k;
  i = 0;
  j = 0;
  k = low;

  //loop until we reach the end of one of the arrays
  while (i < n1 && j < n2) {
    if (L[i] <= M[j]) {
      arr[k] = L[i];
      i++;
    } else {
      arr[k] = M[j];
      j++;
    }
    k++;
  }

  //Traverse the leftover elemets of te other array
  while (i < n1) {
    arr[k] = L[i];
    i++;
    k++;
  }

  while (j < n2) {
    arr[k] = M[j];
    j++;
    k++;
  }
}

void mergerSort(int arr[], int low, int high) {
  if (low < high) {
    // divide the array into two smaller arrays with the midpoint m
    int m = low + (high - low) / 2;

    mergerSort(arr, low, m);
    mergerSort(arr, m + 1, high);

    // Merge the sorted subarrays
    merge(arr, low, m, high);
  }
}

// Print the array
void printArray(int arr[], int size) {
  for (int i = 0; i < size; i++)
    cout << arr[i] << " ";
  cout << endl;
}


void insertionSort(int ar[], int n)
{
    int i, temp, j;
    for (i = 1; i < n; i++)
    {
        temp = ar[i];
        j = i - 1;
        while (j >= 0 && ar[j] > temp)
        {
            ar[j + 1] = ar[j];
            j = j - 1;
        }
        ar[j + 1] = temp;
    }
}


int partition(int ar[] , int low, int high){

    //selecting last element as pivotIndex
    int pivotIndex  = high;
    //Since we are increamenting first, we set the pointer element to 1 less than low index
    int pointer = low -1;

    for (int i = low; i < high; i++)
    {
        if(ar[i] <= ar[pivotIndex]){
            pointer++;
            swap(ar[i],ar[pointer]);
            
        }
    }
    swap(ar[pointer+1],ar[pivotIndex]);
    return pointer+1;
}

void quickSort(int ar[] , int low, int high){
    if(low<high){
        int p = partition(ar, low, high);
        quickSort(ar, low , p-1);
        quickSort(ar,p+1, high);
    }
}


int partitionRandom(int ar[] , int low, int high){
    //Select a random index as pivotpoint
    int pivotIndex = low + (rand()% (high-low+1));
    //Swap that element with the last element
    swap(ar[high] , ar[pivotIndex]);
    //Now do the regular quicksort all over again
    pivotIndex  = high;
    int pointer = low -1;

    for (int i = low; i < high; i++)
    {
        if(ar[i] <= ar[pivotIndex]){
            pointer++;
            swap(ar[i],ar[pointer]);
            
        }
    }
    swap(ar[pointer+1],ar[pivotIndex]);
    return pointer+1;

}

void quickSortRandom(int ar[] , int low, int high){
    if(low<high){
        int p = partitionRandom(ar, low, high);
        quickSortRandom(ar, low , p-1);
        quickSortRandom(ar,p+1, high);
    }
}



int ar[100000];
//Randomized seeding
void initialize_ar(int n,int seed){
    srand(seed);
    for(int i=0;i<n;i++){
        ar[i]=rand();
    }
}

int main(){

    freopen("output.csv","w",stdout);

    int i,j,n,seed=1905093,count=20;
    int valn[6]={5,10,100,1000,10000,100000};
    //clock_t time_start;
    double sort_time=0,merge_time=0,quick_time=0,rand_quick_time=0,insertion_time=0,sorted_quick_time=0,sorted_rand_quick_time;

    cout<<",,,Time Required in ms"<<endl;
    cout<<"Size(n),STL sort(),Merge Sort,Quick Sort,Randomized QS,Sorted QS,Randomized Sorted QS,Insertion Sort"<<endl;
    for(i=0;i<6;i++){
        n=valn[i];

        for(j=1;j<=count;j++){
            initialize_ar(n,seed);
            auto time_start = high_resolution_clock::now();
            sort(ar,ar+n);
            auto time_end = high_resolution_clock::now();
            sort_time += (double)duration_cast<nanoseconds>(time_end - time_start).count()/1000000;
        }
        sort_time/=count;
        
        for(j=1;j<=count;j++){
            initialize_ar(n,seed); 
            auto time_start = high_resolution_clock::now();
            mergerSort(ar,0,n-1);
            auto time_end = high_resolution_clock::now();
            merge_time += (double)duration_cast<nanoseconds>(time_end - time_start).count()/1000000;
        }
        merge_time/=count;

        for(j=1;j<=count;j++){
            initialize_ar(n,seed);  
            auto time_start = high_resolution_clock::now();
            quickSort(ar,0,n-1);
            auto time_end = high_resolution_clock::now();
            quick_time += (double)duration_cast<nanoseconds>(time_end - time_start).count()/1000000;
        }

        quick_time/=count;

        for(j=1;j<=count;j++){
            initialize_ar(n,seed);  
            sort(ar,ar+n);
            auto time_start = high_resolution_clock::now();
            quickSort(ar,0,n-1);
            auto time_end = high_resolution_clock::now();
            sorted_quick_time += (double)duration_cast<nanoseconds>(time_end - time_start).count()/1000000;
        }
        sorted_quick_time/=count;

        for(j=1;j<=count;j++){
            initialize_ar(n,seed);  
            sort(ar,ar+n);
            auto time_start = high_resolution_clock::now();
            quickSortRandom(ar,0,n-1);
            auto time_end = high_resolution_clock::now();
            sorted_rand_quick_time += (double)duration_cast<nanoseconds>(time_end - time_start).count()/1000000;
        }
        sorted_rand_quick_time/=count;

        for(j=1;j<=count;j++){
            initialize_ar(n,seed);  
            auto time_start = high_resolution_clock::now();
            quickSortRandom(ar,0,n-1);
            auto time_end = high_resolution_clock::now();
            rand_quick_time += (double)duration_cast<nanoseconds>(time_end - time_start).count()/1000000;
        }
        rand_quick_time/=count;

        for(j=1;j<=count;j++){
            initialize_ar(n,seed);
            auto time_start = high_resolution_clock::now();
            insertionSort(ar,n);
            auto time_end = high_resolution_clock::now();
            insertion_time += (double)duration_cast<nanoseconds>(time_end - time_start).count()/1000000;
        }
        insertion_time=insertion_time/count;

        cout<<fixed<<n<<","<<sort_time<<","<<" "<<merge_time<<","<<quick_time<<","
        <<rand_quick_time<<","<<sorted_quick_time<<","<<sorted_rand_quick_time<<","<<insertion_time<<endl;
    }

}