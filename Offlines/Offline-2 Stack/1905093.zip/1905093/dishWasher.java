import java.util.Scanner;

class dishClass{
    private int id;
    private int push_time;
    private int clean_time;


    dishClass(int id,int push_time){
        this.id=id;
        this.push_time=push_time;
    }
    dishClass(int id,int push_time,int clean_time){
        this.id=id;
        this.push_time=push_time;
        this.clean_time = clean_time;
    }


    public void setClean_time(int clean_time) {
        this.clean_time = clean_time;
    }

    public int getClean_time() {
        return clean_time;
    }

    public int getPush_time() {
        return push_time;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "id=" + id + ", dish_push_time=" + push_time + ", dish_clean_time=" + clean_time ;
    }
}

 class tester4{
     public static void main(String[] args) {

         int id,t,s,lastDish_wash_time=-1,n,x;
         Scanner scn = new Scanner(System.in);


         //Array_Implementation
//         ArrayImplementation<dish> dirtyStack = new ArrayImplementation<>(10);
//         ArrayImplementation<dish> cleanStack = new ArrayImplementation<>(10);
//         ArrayImplementation<Integer> full_meal = new ArrayImplementation<>(10);

         //Linked_List_Implementation
         LinkedListImplementation<dishClass> dirtyStack = new LinkedListImplementation<>(10);
         LinkedListImplementation<dishClass> cleanStack = new LinkedListImplementation<>(10);
         LinkedListImplementation<Integer> fullMeal = new LinkedListImplementation<>(10);


         n = scn.nextInt();
         x= scn.nextInt();

         //Course Time for each course
         int[] course_time = new int[x];
         for (int i = 0; i < x; i++) {
             int temp = scn.nextInt();
             course_time[i]=temp;
         }

         while(true){
             id= scn.nextInt(); //
             t=scn.nextInt();
             s= scn.nextInt();
             if(id==0)break; //Break command for 0 0 0

             dishClass ar = new dishClass(s-1,t);

             if(t<=lastDish_wash_time){
                 dirtyStack.push(ar);
             }
             else{
                 while(dirtyStack.length()>0 && t>lastDish_wash_time){
                     dishClass washing=dirtyStack.pop();
                     lastDish_wash_time+=course_time[washing.getId()];
                     washing.setClean_time(lastDish_wash_time);
                     cleanStack.push(washing);
                 }
                 dirtyStack.push(ar);
                 if(dirtyStack.length()==1){
                     lastDish_wash_time=t+course_time[ar.getId()]-1;
                     ar.setClean_time(lastDish_wash_time);
                     dirtyStack.pop();
                     cleanStack.push(ar);
                 }
             }
             if(s==x)
                 fullMeal.push(id);
         }
         while(dirtyStack.length()>0){
             dishClass washing=dirtyStack.pop();
             lastDish_wash_time+=course_time[washing.getId()];
             washing.setClean_time(lastDish_wash_time);
             cleanStack.push(washing);
         }
         System.out.println(lastDish_wash_time);
         String output="";
         for(int i=0;i<cleanStack.length();){
             output=cleanStack.pop().getClean_time()+output;
             if(cleanStack.length()>0)
                 output=","+output;
         }
         System.out.println(output);

         //Finding persons who had full meals
         if(fullMeal.length()==n)
             System.out.println("Y");
         else
             System.out.println("N");
         for(int i=0;i<fullMeal.length();)
             System.out.print(fullMeal.pop()+",");

     }
     }



