import java.util.Arrays;
import java.util.Scanner;



public class OneArrayTwoStack {

    public static void main(String[] args) {

        int id,t,s,lastDish_wash_time=-1,n,x;
        Scanner scn = new Scanner(System.in);


        n = scn.nextInt();
        x= scn.nextInt();
        int[] course_time = new int[x];
        for (int i = 0; i < x; i++) {
            int temp = scn.nextInt();
            course_time[i]=temp;
        }


        dishClass[] total_Stack = new dishClass[n*x];

        //Array_Implementation
         ArrayImplementation<dishClass> dirtyStack = new ArrayImplementation<dishClass>(total_Stack,n*x,1);
         ArrayImplementation<dishClass> cleanStack = new ArrayImplementation<dishClass>(total_Stack,n*x,-1);
         ArrayImplementation<Integer> fullMeal = new ArrayImplementation<>(10);

        //Linked_List_Implementation
//        LinkedListImplementation<dishClass> dirtyStack = new LinkedListImplementation<>(10);
//        LinkedListImplementation<dishClass> cleanStack = new LinkedListImplementation<>(10);
//        LinkedListImplementation<Integer> full_meal = new LinkedListImplementation<>(10);




        while(true){
            id= scn.nextInt();
            t=scn.nextInt();
            s= scn.nextInt();
            if(id==0)break; //Break command for 0 0 0

            dishClass ar = new dishClass(s-1,t);

            if(t<=lastDish_wash_time){
                dirtyStack.push(ar);
            }
            else{
                while(dirtyStack.length()>0 && t>lastDish_wash_time){
                    dishClass washing=dirtyStack.pop();
                    lastDish_wash_time+=course_time[washing.getId()];
                    washing.setClean_time(lastDish_wash_time);
                    cleanStack.push(washing);
                }
                dirtyStack.push(ar);
                if(dirtyStack.length()==1){
                    lastDish_wash_time=t+course_time[ar.getId()]-1;
                    ar.setClean_time(lastDish_wash_time);
                    dirtyStack.pop();
                    cleanStack.push(ar);
                }
            }
            if(s==x)
                fullMeal.push(id);
        }
        while(dirtyStack.length()>0){
            dishClass washing=dirtyStack.pop();
            lastDish_wash_time+=course_time[washing.getId()];
            washing.setClean_time(lastDish_wash_time);
            cleanStack.push(washing);
        }
        System.out.println(lastDish_wash_time);

        //Printing
        String output="";
        for(int i=0;i<cleanStack.length();){
            output=cleanStack.pop().getClean_time()+output;
            if(cleanStack.length()>0)
                output=","+output;
        }
        System.out.println(output);

        //Finding persons who had full meals
        if(fullMeal.length()==n)
            System.out.println("Y");
        else
            System.out.println("N");
        for(int i=0;i<fullMeal.length();)
            System.out.print(fullMeal.pop()+",");

    }

}
