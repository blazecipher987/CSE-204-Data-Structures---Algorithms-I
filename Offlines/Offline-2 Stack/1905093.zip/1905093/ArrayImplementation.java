import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class ArrayImplementation<E> implements Stack_ADT<E>{

    private int maxSize;
    private int top;
    private E[] listArray;
    private int direction;

    ArrayImplementation(){
        top=0;
        direction=1;
    }

    ArrayImplementation(E[] ar, int size, int dir) {
        if(dir==1)
            listArray = Arrays.copyOf(ar, ar.length+1);
        else if(dir==-1){
            E[] temp =(E[]) new Object[ar.length];
            int j=0;
            for (int i = ar.length-1; i >=0 ; i--) {
                temp[j] = ar[i];
                j++;
            }
            listArray=temp;
        }


//        for (int i = 0; i < listArray.length; i++) {
//            //System.out.println(listArray[i]);
//        }
        maxSize = size;

        direction=dir;
        if(direction==1)top = ar.length;
        else
            top = -1;

    }

    ArrayImplementation(int size){
        listArray =  (E[])new Object[size];
        maxSize = size;
        top = 0;
        direction=1;
        //System.out.println(top);
    }

    public void clear(){
        top=0;
    }

    @Override
    public void push(E x) {
        //System.out.println("insider push??");
        if(direction==1){
            //System.out.println("Insider dir 1");
            if(top==maxSize){
                //System.out.println("Inside Length increase");
                E[] temp = (E[])new Object[maxSize*2];
                maxSize=maxSize*2;
                for (int i = 0; i < top; i++) {
                    temp[i]=listArray[i];
                }
                temp[top]=x;
                listArray=temp;
            }
            listArray[top]=x;
            top++;
            //System.out.println(top);
        }
        if(direction==-1){
            //System.out.println("Insider dir -1");
            if(top==-1){
                //System.out.println("insider length increase with -1");
                int prev_maxSize= maxSize;
                E[] temp = (E[])new Object[maxSize*2];
                maxSize = maxSize*2;
                int curr_maxSize=maxSize;

                for (int i = curr_maxSize-1,j=prev_maxSize-1; j >top ; i--,j--) {
                    temp[i]=listArray[j];
                }
                top = maxSize-prev_maxSize-1;
                //System.out.println(top);
                temp[top]=x;

                listArray=temp;
            }
            //System.out.println(x);
            listArray[top]=x;
            //System.out.println(listArray[top]);
            top--;
        }

    }

    @Override
    public E pop() {
        if(direction==1){
            if(top<1){
                System.out.println("Not Possible to pop an empty list");
                return null;
            }
            return listArray[--top];
        }

        else{
            if(top>maxSize){
                System.out.println("Not possible to print an empty list");
                return null;
            }
            //System.out.println("Size: "+maxSize+" "+"Top: "+ top +" length: "+length());
          //  System.out.println("Curr: "+top);
            return listArray[++top];
        }

    }

    @Override
    public int length() {
        if(direction==1)
            return top;
        else
            return maxSize-top-1;
    }

    @Override
    public E topValue() {
        if(direction==1)
            return listArray[top-1];
        else
            return listArray[top+1];
    }

    @Override
    public void setDirection(int dir) {
        if(dir==-1 || dir==1){
            direction=dir;
            if(dir==-1)
                top=maxSize-1;
        }
        else
            return;
    }

}

//class tester {
//    public static void print(ArrayImplementation<Integer> ar) {
//        int[] a = new int[ar.length()];
//        int i = 0;
//        while (ar.length() != 0) {
//            int x = ar.pop();
//            a[i] = x;
//            i++;
//        }
//        System.out.print("< ");
//        for (i = a.length - 1; i >= 0; i--) {
//            System.out.print(a[i] + " ");
//        }
//        System.out.println(" >");
//        for (i = a.length - 1; i >= 0; i--) {
//            ar.push(a[i]);
//        }
//    }
//
//    public static void main(String[] args) {
//        Scanner sc = new Scanner(System.in);
//        int size = sc.nextInt();
//
//        Integer[] a = new Integer[5];
//        for (int i = 0; i < 5; i++) {
//            a[i]=i;
//        }
//
//        ArrayImplementation<Integer> ar = new ArrayImplementation<>(size);
//        //ArrayImplementation<Integer> ar = new ArrayImplementation<>(a,a.length,-1);
//
////
//        //ar.setDirection(-1);
//        //int x = sc.nextInt();
//        //System.out.println(ar.length());
//
////        for (int i = 0; i < size; i++) {
////            int temp = sc.nextInt();
////            ar.push(temp);
////        }
//
//
//        //System.out.println(ar.length());
//        print(ar);
//
//        int p;
//        int q = -1;
//        while (q != 0 || (q > 0 && q <= 6)) {
//            q = sc.nextInt();
//            p = sc.nextInt();
//
//            if (q == 0) {
//                System.exit(0);
//            }
//            if (q == 1) {
//                ar.clear();
//                System.out.println("< >");
//                System.out.println("-1");
//
//            }
//            if (q == 2) {
//                ar.push(p);
//                print(ar);
//                System.out.println("-1");
//
//            }
//            if (q == 3) {
//                int x = ar.pop();
//                print(ar);
//                System.out.println(x);
//
//            }
//            if (q == 4) {
//                int x = ar.length();
//                print(ar);
//                System.out.println(x);
//
//            }
//            if (q == 5) {
//                int x = ar.topValue();
//                print(ar);
//                System.out.println(x);
//            }
//
//
//
//        }
//    }
//}