import java.util.Scanner;

class Customer{
    private int enteringTime;
    private int serviceTime;
    private int customerNo;

    Customer(int e,int s,int i){
        enteringTime=e;
        serviceTime=s;
        customerNo=i;
    }
    Customer(){

    }

    public int getEnteringTime() {
        return enteringTime;
    }

    public void setEnteringTime(int enteringTime) {
        this.enteringTime = enteringTime;
    }

    public int getServiceTime() {
        return serviceTime;
    }

    public void setServiceTime(int serviceTime) {
        this.serviceTime = serviceTime;
    }

    public int getCustomerNo() {
        return customerNo;
    }

    public void setCustomerNo(int customerNo) {
        this.customerNo = customerNo;
    }
}


public class bankQueue {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int Queue1CurrTime=0;
        int Queue2CurrTime=0;


        Customer temp;
        int enterTime;

        int n = sc.nextInt();
        ArrayQueue<Customer> Q1 = new ArrayQueue<>(n);
        ArrayQueue<Customer> Q2 = new ArrayQueue<>(n);

        for (int i = 0; i < n; i++) {

            enterTime = sc.nextInt();
            int serviceTime = sc.nextInt();

            temp = new Customer(enterTime,serviceTime,i);



            if(Q1.length()==0 && Q2.length()==0){
                if(Queue1CurrTime<=enterTime){
                    Q1.enqueue(temp);
                }
                else if(Queue2CurrTime<=enterTime){
                    Q2.enqueue(temp);
                }
                else {
                    Q1.enqueue(temp);
                }
            }

            else if(Q1.length()<=Q2.length()){
                Q1.enqueue(temp);
            }
            else{
                Q2.enqueue(temp);
            }

            while ((Q1.length()!=0 && Queue1CurrTime<=enterTime) || (Q2.length()!=0 && Queue2CurrTime<=enterTime)){

                if((Q1.length()!=0 && Queue1CurrTime<=enterTime)){
                    temp = Q1.dequeue();

                    if(Queue1CurrTime<temp.getEnteringTime()){
                        Queue1CurrTime =  temp.getEnteringTime()+temp.getServiceTime();
                    }
                    else {
                        Queue1CurrTime+= temp.getServiceTime();
                    }
                }

                if((Q2.length()!=0 && Queue2CurrTime<=enterTime)){
                    temp = Q2.dequeue();

                    if(Queue2CurrTime<temp.getEnteringTime()){
                        Queue2CurrTime = temp.getEnteringTime()+temp.getServiceTime();
                    }
                    else{
                        Queue2CurrTime+= temp.getServiceTime();
                    }
                }

                while (Q1.length()<Q2.length() && Q2.length()!=0){
                    temp = Q2.leaveQueue();
                    Q1.enqueue(temp);
                }
                while (Q2.length() +1 <Q1.length() && Q1.length()!=0){
                    temp = Q1.leaveQueue();
                    Q2.enqueue(temp);
                }

            }

        }

        enterTime = Math.min(Queue1CurrTime,Queue2CurrTime);

        while (Q1.length()!=0 || Q2.length()!=0){

            if((Q1.length()!=0 && Queue1CurrTime<=enterTime)){
                temp = Q1.dequeue();

                if(Queue1CurrTime<temp.getEnteringTime()){
                    Queue1CurrTime =  temp.getEnteringTime()+temp.getServiceTime();
                }
                else {
                    Queue1CurrTime+= temp.getServiceTime();
                }
            }

            if((Q2.length()!=0 && Queue2CurrTime<=enterTime)){
                temp = Q2.dequeue();

                if(Queue2CurrTime<temp.getEnteringTime()){
                    Queue2CurrTime = temp.getEnteringTime()+temp.getServiceTime();
                }
                else{
                    Queue2CurrTime+= temp.getServiceTime();
                }
            }

            while (Q1.length()<Q2.length() && Q2.length()!=0){
                temp = Q2.leaveQueue();
                Q1.enqueue(temp);
            }
            while (Q2.length() +1 <Q1.length() && Q1.length()!=0){
                temp = Q1.leaveQueue();
                Q2.enqueue(temp);
            }

            enterTime++;
        }

        System.out.println(Queue1CurrTime);
        System.out.println(Queue2CurrTime);

    }
}
