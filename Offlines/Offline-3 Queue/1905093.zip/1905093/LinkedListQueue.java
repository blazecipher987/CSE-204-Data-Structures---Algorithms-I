import java.util.Scanner;

class Node<E>{
    E element;
    Node<E> next;

    Node(E it, Node nextVal){
        element=it;
        next=nextVal;
    }
    Node(Node nextVal){
        next=nextVal;
    }

    public void setNext(Node nextVal){
        next=nextVal;
    }

}



public class LinkedListQueue<E> implements queueADT<E> {

    private Node<E> front;
    private Node<E> curr;
    private Node<E> rear;
    E[] listArray;
    int maxSize;
    int count;

    LinkedListQueue(){
        front=rear= new Node<>(null);
        count=0;
    }

    @Override
    public void clear() {
        front.next=null;
    }

    @Override
    public void enqueue(E it) {
        //System.out.println("En");
        rear.setNext(new Node(it,null));
        rear=rear.next;
        count++;
    }

    @Override
    public E dequeue() {
        if(count==0){
            System.out.println("Can't dequeue an empty queue");
            return null;
        }
        else {
            E x = front.next.element;
            front.setNext(front.next.next);
            count--;
            if(front.next==null){
                rear=front;
            }
            return x;
        }

    }

    @Override
    public E frontValue() {
        if(count==0){
            System.out.println("Can't get Front-Value from an empty queue");
            return null;
        }
        else {
            E x = front.next.element;
            return x;
        }
    }

    @Override
    public E rearValue() {
        if(count==0){
            System.out.println("Can't get Rear-Value from an empty queue");
            return null;
        }
        E x = rear.element;
        return x;
    }

    @Override
    public int length() {
        return count;
    }

    @Override
    public E leaveQueue() {
        E x = rear.element;
        Node temp = front;
        while (temp.next!=rear){
            temp=temp.next;
        }
        rear=temp;
        count--;
        return x;
    }
}

class tester2{

    public static void print(LinkedListQueue<Integer> arr){
        int[] temp = new int[arr.length()];
        int i=0;
        System.out.print("< ");
        while (arr.length()>0){
            temp[i]= arr.dequeue();
            i++;
        }
        for (int j = 0; j < temp.length; j++) {
            System.out.print(temp[j]+" ");
        }

        i = 0;
        while (i!=temp.length){
            arr.enqueue(temp[i]);
            i++;
        }

        System.out.println(" >");
    }

    public static void main(String[] args) {
        LinkedListQueue<Integer> ar = new LinkedListQueue<>();
        Scanner sc = new Scanner(System.in);

        int n= sc.nextInt();
        for (int i = 0; i < n; i++) {
            int temp = sc.nextInt();
            ar.enqueue(temp);
        }


        print(ar);
        int p;
        int q = -1;
        while (q != 0 || (q > 0 && q <= 7)) {
            q = sc.nextInt();
            p = sc.nextInt();

            if (q == 0) {
                System.exit(0);
            }
            if (q == 1) {
                ar.clear();
                System.out.println("< >");
                System.out.println("-1");
            }
            if (q == 2) {
                ar.enqueue(p);
                print(ar);
                System.out.println("-1");
            }
            if (q == 3) {
                int x = ar.dequeue();
                print(ar);
                System.out.println(x);
            }
            if (q == 4) {
                int x = ar.length();
                print(ar);
                System.out.println(x);
            }
            if (q == 5) {
                int x = ar.frontValue();
                print(ar);
                System.out.println(x); }

            if (q == 6) {
                int x = ar.rearValue();
                print(ar);
                System.out.println(x); }

            if (q == 7) {
                int x = ar.leaveQueue();
                print(ar);
                System.out.println(x); }
        }

    }
}