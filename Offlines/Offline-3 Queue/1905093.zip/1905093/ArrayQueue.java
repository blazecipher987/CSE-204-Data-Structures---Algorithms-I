import java.util.Arrays;
import java.util.Scanner;

public class ArrayQueue<E> implements queueADT<E> {
    private int maxSize;
    private E[] listArray;
    private int front;
    private int rear;
    private int count;


    ArrayQueue(int size){
        listArray =(E[]) new Object[size];
        maxSize=size;
        front=1;
        rear=0;
    }

    ArrayQueue(E[] tempAr){
        listArray = Arrays.copyOf(tempAr,tempAr.length+1);
        maxSize =  tempAr.length;
        front=1;
        rear = tempAr.length;
    }

    @Override
    public void clear() {
        rear=0;
        front=1;
    }

    @Override
    public void enqueue(E it) {
        if((rear+2)%maxSize!=front){
            rear = (rear+1)%maxSize;
            listArray[rear]=it;
        }

        else{
            System.out.println("size increase");
            E[] temp =(E[]) new Object[maxSize*2];
            maxSize=maxSize*2;
            int temp_size= length();

            int i=1;
            while (length()!=0){
                E x = dequeue();
                temp[i]=x;
                i++;
            }

            front=1;
            rear=temp_size;
            listArray=temp;
            rear = (rear+1)%maxSize;
            listArray[rear]=it;

        }
    }



    @Override
    public E dequeue() {
        if (length()==0){
            System.out.println("There is no element to deque from the queue");
            return null;
        }
        E x = listArray[front];
        front = (front+1)% maxSize;

        return x;
    }



    @Override
    public E frontValue() {
        if (length()==0){
            System.out.println("There is no element to deque from the queue");
            return null;
        }
        E x = listArray[front];
        return x;
    }

    @Override
    public E rearValue() {
        return listArray[rear];
    }

    @Override
    public int length() {
        return ((rear+maxSize)-front+1)%maxSize;
    }

    @Override
    public E leaveQueue() {
        E x = listArray[rear];
        rear--;
        if(rear==-1){
            rear= rear+maxSize;
        }
        count--;

        return x;
    }

}

class tester{

    public static void print(ArrayQueue<Integer> arr){

        int[] temp = new int[arr.length()];
        int i=0;
        System.out.print("< ");
        while (arr.length()>0){
            temp[i]= arr.dequeue();
            i++;
        }
        for (int j = 0; j < temp.length; j++) {
            System.out.print(temp[j]+" ");
        }

        i = 0;
        while (i!=temp.length){
            arr.enqueue(temp[i]);
            i++;
        }

        System.out.println(" >");
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        ArrayQueue<Integer> ar = new ArrayQueue<>(n);

        for (int i = 0; i < n; i++) {
            int temp = sc.nextInt();
            ar.enqueue(temp);
        }

        print(ar);

        int p;
        int q = -1;
        while (q != 0 || (q > 0 && q <= 7)) {
            q = sc.nextInt();
            p = sc.nextInt();

            if (q == 0) {
                System.exit(0);
            }
            if (q == 1) {
                ar.clear();
                System.out.println("< >");
                System.out.println("-1");
            }
            if (q == 2) {
                ar.enqueue(p);
                print(ar);
                System.out.println("-1");
            }
            if (q == 3) {
                int x = ar.dequeue();
                print(ar);
                System.out.println(x);
            }
            if (q == 4) {
                int x = ar.length();
                print(ar);
                System.out.println(x);
            }
            if (q == 5) {
                int x = ar.frontValue();
                print(ar);
                System.out.println(x); }

            if (q == 6) {
                int x = ar.rearValue();
                print(ar);
                System.out.println(x); }

            if (q == 7) {
                int x = ar.leaveQueue();
                print(ar);
                System.out.println(x); }
        }
    }
}