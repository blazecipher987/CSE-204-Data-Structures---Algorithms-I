import java.io.*;
import java.util.*;


//A utility class to help us with finding the path and number of moves
class utility{
    int v; //node
    int distance; //to keep track of the minimum distance
    int [] parent; //to keep track of the parent of a node for getting the shortest sequence

    utility(int n){
        parent = new int[n];
    }

    public int getParent(int x) {
        return parent[x];
    }

    public void setParent(int par, int index) {
        this.parent[index] = par;
    }

    public int getV() {
        return v;
    }

    public void setV(int v) {
        this.v = v;
    }

    public int getDistance() {
        return distance;
    }

    public void setDistance(int distance) {
        this.distance = distance;
    }
}


class SnakesLadder
{
    int [] board; //The board containing the snake and ladders
    int [] visitedNodes; //To keep track of which nodes we have already visited
    int ans; //To keep track of the final answer,number of moves required to reach destination
    int diceSides; //How many sides the dice has
    utility temp; //Used for keeping track of parent of each node,hence finding the sequence

    SnakesLadder(int[] ar , int dice){
        board = Arrays.copyOf(ar, ar.length);
        visitedNodes = new int[ar.length+1];
        diceSides = dice;
        temp = new utility(ar.length);
        ans=0;
    }

    //Get minimum dice move to reach last cell(if reachable)
    public int getMinDiceThrows(int[] move, int n){
        utility qe = new utility(n);
        Queue<utility> q = new LinkedList<>(); //Queue used for BFS

        qe.setV(1); //Starting from vertex 1
        qe.setParent(-1, 1); //The parent of vertex 1 is not in the board
        qe.setDistance(0); //Starting point has traversed zero distance

        visitedNodes[1] = 1;// Mark the node 1 as visited and enqueue it.
        q.add(qe); //Add the first node to the queue

        // Do a BFS starting from vertex at index 1
        while (!q.isEmpty())
        {
            qe = q.remove();
            int v = qe.getV();

            // If front vertex is the destination vertex, we are done with finding the min throws
            //But we will still continue the loop to see all reachable nodes
            if (v == n - 1){
                ans = qe.getDistance();
            }

            /* Dequeue the front vertex and
            enqueue its adjacent vertices (or cell
            numbers reachable through dice throw) */
            for (int j = v + 1; j <= (v + diceSides) && j < n; ++j)
            {
                // If this cell is already visited, then ignore
                // Otherwise, calculate its distance and mark it as visited
                if (visitedNodes[j] == 0)
                {
                    utility a = new utility(n);
                    a.setDistance((qe.getDistance() + 1)) ;
                    visitedNodes[j] = 1;

                    // Check if there is a snake or ladder at j,then tail of snake or top of ladder become the adjacent of 'i'
                    if (move[j] != -1){
                        temp.setParent(v,j);
                        a.setV(move[j]) ;
                        visitedNodes[move[j]]=1;
                        temp.setParent(j,move[j]);
                    }

                    else if (temp.getParent(j)==0){
                        temp.setParent(v,j);
                        a.setV(j);
                    }
                    q.add(a);
                }
            }
        }

        // We reach here when Destination node couldn't be visited and all reachable nodes were visited
        if(visitedNodes[n-1]==0)
            return -1;
        //Destination node was visited and all reachable nodes were also visited
        return ans;
    }

    //TO get the shortest path to destination if it can be reached
    public Stack getPathSequence(int n){
        Stack<Integer> s = new Stack<>();
        if(visitedNodes[n-1]!=0){
            s.push(n-1);
            for (int i = n-1; i != 1;) {
                int t = temp.getParent(i);
                s.push(t);
                i = temp.getParent(i);
            }
            return s;
        }
        else
            return s;
    }

    //The nodes that can be reached in the board
    public Queue getReachableNodes(int n){
        boolean flag = true;
        Queue<Integer> q= new LinkedList<>();

        //find if any node is unvisited
        for (int i = 1; i < n; i++) {
            if(visitedNodes[i]==0){
                flag=false;
                break;
            }
        }

        //if all are visited
        if(flag){
            return q;
        }
        //if some are unvisited
        else{
            System.out.println();
            for (int i = 1; i < n; i++) {
                if(visitedNodes[i]==0){
                    q.add(i);
                }
            }
            return q;
        }
    }

}

class tester{
    public static void main(String[] args) throws FileNotFoundException {


        try {
            //Read Input from txt file
            File myObj = new File("src/inputs.txt");
            FileWriter fWriter = new FileWriter("src/outputs.txt");
            BufferedWriter b =  new BufferedWriter(fWriter);

            Scanner myReader = new Scanner(myObj);
            int test = Integer.parseInt(myReader.nextLine());

            while(test!=0){
                String x = myReader.nextLine();
                String[] s = x.split(" ");
                int N = Integer.parseInt(s[1]) +1; //Added 1 since we are starting from index 1
                int[] moves = new int[N]; //This array basically represents the board
                for (int i = 1; i < N; i++)
                    moves[i] = -1;
                int dice = Integer.parseInt(s[0]);

                int ladders = Integer.parseInt(myReader.nextLine());
                for (int i = 0; i < ladders; i++) {
                    String data = myReader.nextLine();
                    String[] str = data.split(" ");
                    moves[Integer.parseInt(str[0])] = Integer.parseInt(str[1]);
                }
                int snakes = Integer.parseInt(myReader.nextLine());
                for (int i = 0; i < snakes; i++) {
                    String data = myReader.nextLine();
                    String[] str = data.split(" ");
                    moves[Integer.parseInt(str[0])] = Integer.parseInt(str[1]);
                }

                SnakesLadder game = new SnakesLadder(moves,dice);
                String s1 = String.valueOf(game.getMinDiceThrows(moves,N));
                //String s2 = game.getPathSequence(N);
                Stack s2 = game.getPathSequence(N);
                //String s3  = game.getReachableNodes(N);
                Queue s3 = game.getReachableNodes(N);
                String x2 = "";
                String x3 = "";
                if(s2.isEmpty()){
                    x2 = "No solution";
                }
                else {
                    x2 = x2 + s2.pop();
                    while (!s2.isEmpty()){
                        x2 = x2 + " -> " +  s2.pop();
                    }
                }
                if(s3.isEmpty()){
                    x3 = "All  are reachable" ;
                }
                else{
                    while (!s3.isEmpty()){
                        x3 = x3 + s3.poll() + " ";
                    }
                }


                b.write(s1 + "\n");
                b.write(x2 + " \n");
                b.write(x3+ "\n" + "\n");

                test--;
            }


            myReader.close();
            b.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}


