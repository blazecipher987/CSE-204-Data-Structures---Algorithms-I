import java.util.Scanner;

public class tester {

    //For LinkedList.java printing
//    public static void print(LinkedList<Integer> list,int t){
//        int temp= list.currPos();
//        System.out.print("< ");
//        list.moveToStart();
//
//        for(int i=0;i< list.length();i++)
//        {
//            if(i==temp)
//            {
//                System.out.print(" | ");
//            }
//            System.out.print(" "+list.getValue()+" ");
//            list.next();
//        }
//        System.out.println(" >");
//        list.moveToPos(temp);
//
//    }


    //For Array.java printing
    public static void print(Array arr, int t){
        int flag=0;
        System.out.print("<");
        int temp = arr.currPos();
        for (int i = 0; i < t; i++) {
            if(i==temp){
                //System.out.print("CURR: " +currPosition);
                System.out.print("| ");
                flag=1;
            }
            arr.moveToPos(i);
            System.out.print(arr.getValue()+" ");
        }
        arr.moveToPos(temp);
        if(flag==0){
            System.out.print(" |");
        }
        System.out.print(">");
        System.out.println();
    }

    public static void main(String[] args) {
        Scanner sc1 = new Scanner(System.in);
        int count_size= sc1.nextInt();
        int memory_unit= sc1.nextInt();
        Integer[] arr=new Integer[3];
        arr[0]=3;
        arr[1]=5;
        arr[2]=6;
        //LinkedList<Integer> ar = new LinkedList<Integer>();
        Array<Integer> ar = new Array<Integer>(count_size, memory_unit);

        for(int i=0;i<count_size;i++){
            int temp = sc1.nextInt();
            ar.append(temp);
        };
        //System.out.println(ar.length());
        print(ar,ar.length());


        Scanner sc = new Scanner(System.in);
        int p;
        int q = -1;
        while (q != 0 || (q > 0 && q <= 13)) {
            q = sc.nextInt();
            p = sc.nextInt();

            if (q == 0) {
                System.exit(0);
            }
            if (q == 1) {
                ar.clear();
                System.out.println("< >");
                System.out.println("-1");

            }
            if (q == 2) {
                ar.insert(p);
                print(ar,ar.length());
                System.out.println("-1");

            }
            if (q == 3) {
                ar.append(p);
                print(ar,ar.length());
                System.out.println("-1");

            }
            if (q == 4) {
                int x = ar.remove();
                print(ar,ar.length());
                System.out.println(x);

            }
            if (q == 5) {
                ar.moveToStart();
                print(ar,ar.length());
                System.out.println("-1");
            }
            if (q == 6) {
                ar.moveToEnd();
                print(ar,ar.length());
                System.out.println("-1");
            }
            if (q == 7) {
                ar.prev();
                print(ar,ar.length());
                System.out.println("-1");

            }
            if (q == 8) {
                ar.next();

                print(ar,ar.length());
                System.out.println("-1");
            }
            if (q == 9) {
                int temp = ar.length();

                print(ar,ar.length());
                System.out.println(temp);
            }
            if (q == 10) {
                int temp = ar.currPos();

                print(ar,ar.length());
                System.out.println(temp);
            }
            if (q == 11) {
                ar.moveToPos(p);

                print(ar,ar.length());
                System.out.println("-1");

            }
            if (q == 12) {

                print(ar,ar.length());
                System.out.println(ar.getValue());
            }
            if (q == 13) {
                int temp = ar.search(p);
                print(ar,ar.length());
                System.out.println(temp);

            }
        }


    }
}
