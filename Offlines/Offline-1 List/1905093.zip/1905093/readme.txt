1) list_ADT contains the interface which is used by Array.java and LinkedList.java

2) Array.java contains the implemnetation of list_ADT.java as a array data structure

3) LinkedList.java contains the implementation of list_ADT as a Linked List data structure.
   This file also contains a Node class which is used by the LinkedList class

4) tester.java contains the print and main function for both Array and Linked List based
   implementation.

5) TNL.java contains main function of it's own which uses both Array.java and LinkedList.java
   to get desired outputs