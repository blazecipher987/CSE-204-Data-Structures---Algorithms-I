import java.util.Scanner;

class node<E> {
    private E element;
    private node<E> next;

    node(E x, node<E> nextNode){
        element=x;
        next=nextNode;
    }
    node(node<E> nextNode){
        next=nextNode;
    }

    node<E> next(){return next;};
    node<E> setNext(node<E> t){
        next=t;
        return next;
    };
    void setElement(E x){
        element=x;
    }
    E getElement(){
        return element;
    }
}


class LinkedList<E> implements list<E>  {

    private node<E> head;
    private node<E> tail;
    private node<E> currPosition;
    private int count;

    LinkedList(){
        currPosition=head=tail=new node<E>(null);
    }
    LinkedList(E[] ar){
        currPosition=head=tail=new node<E>(null);
        for (int i = 0; i < ar.length; i++) {
            tail=tail.setNext(new node<E>(ar[i],null));
            count++;
        }


    }

    @Override
    public void clear() {
        head=tail=currPosition=new node<E>(null); //Delete all access
        count=0;
    }

    @Override
    public void insert(E x) {
        currPosition.setNext(new node<E>(x,currPosition.next()));/*The current node points to a newly created node
                                                                   and the newly created node points to the node the current
                                                                   node was pointing to before*/
        count++;
    }

    @Override
    public void append(E x) {
        tail=tail.setNext(new node<E>(x,null)); /*New tail will point to null while current tail
                                                            will point to the newly created tail*/
        count++;
    }

    @Override

    public E remove(){
        if (currPosition.next() == null)
            return null;
        E it = currPosition.next().getElement(); // Storing to be removed element
        if ( currPosition.next() == tail) {
            if(head==currPosition)
                tail =currPosition;
            else {
                node<E> temp = head;
                while (temp.next() != currPosition)
                    temp = temp.next();
                tail = currPosition;
                currPosition = temp;
            }
        }                   // Removed last
        else
            currPosition.setNext(currPosition.next().next()); // change curPos position
        count--;
        return it;
    }

    @Override
    public void moveToStart() {
        currPosition=head;
    }

    @Override
    public void moveToEnd() {
        node<E> temp = head;
        while(temp.next()!=tail){ //Loop until we are right before the tail
            temp=temp.next();
        }
        currPosition=temp;
    }

    @Override
    public void prev() {
        node<E> temp = head;
        while(temp.next()!=currPosition){
            temp=temp.next();
        }
        currPosition=temp;
    }

    @Override
    public void next() {
        if(currPosition.next()==tail){
            currPosition=tail;
            return;
        }
        currPosition=currPosition.next();
    }

    @Override
    public int length() {
        return count;
    }

    @Override
    public int currPos() {
        node<E> temp = head;
        int i=0;
        while(temp!=currPosition){ //Loop and increment for each time currpos isn't found in iteration
            i++;
            temp= temp.next();
        }
        return i;
    }

    @Override
    public void moveToPos(int x) {
        node<E> temp = head;
        for (int i = 0; i < x; i++) {
            temp= temp.next();
        }
        currPosition= temp;
    }

    @Override
    public E getValue() {
        return currPosition.next().getElement();
    }


    @Override
    public int search(E x) {
        node<E> temp = head;
        temp= temp.next();
        for (int i = 0; temp != null; i++) {
            if(temp.getElement()==x){
                return i;
            }
            temp = temp.next();
        }
        return -1;
    }


}
