import java.util.Scanner;

public class TNL {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int r_stop = sc.nextInt(); //

        //Bus station input
        int b_stop = sc.nextInt();
        //Array<Integer> arr = new Array<Integer>(b_stop,r_stop+1);
        LinkedList<Integer> arr = new LinkedList<>();
        int x1=0;
        for(int i=0;i<b_stop;i++){
            int temp = sc.nextInt();
            arr.append(temp);
            x1 = temp;
        };
        //System.out.println(arr.length());

        //TRAIN station input
        int t_stop = sc.nextInt();
        //Array<Integer> arr2 = new Array<>(t_stop,r_stop+1);
        LinkedList<Integer> arr2 = new LinkedList<>();
        int x2=0;
        for (int i = 0; i < t_stop; i++) {
            int temp = sc.nextInt();
            arr2.append(temp);
            x2=temp;
        }

        int tasks;
        tasks = sc.nextInt();

        //Printing Rickshaw stops
        for (int i = 0; i < r_stop; i++) {
            if(i!=r_stop-1){
                System.out.print(i+",");
            }
            else{
                System.out.println(i);
            }
        }

        //Printing Bus Station outputs
        for(int i=0;i<r_stop;i++){
            int x = arr.search(i);
            if(x==-1){
                System.out.print(",");
            }
            else{
                if(i==x1) // print one comma less for last output
                {
                    System.out.print(i);
                }
                else{
                    System.out.print(i+",");
                }

            }
        };
        System.out.println();

        //Printing Train Station outputs
        for(int i=0;i<r_stop;i++){
            int x = arr2.search(i);
            int y = arr.search(i);
            if(x==-1){
                System.out.print(",");
            }
            else{
                if(i==x2 && y!=-1)// print one comma less for last output
                {
                    System.out.print(i);
                }
                else{
                    if(y!=-1)
                        System.out.print(i+",");
                    else
                        System.out.print(",");
                }

            }
        };

    }
}
