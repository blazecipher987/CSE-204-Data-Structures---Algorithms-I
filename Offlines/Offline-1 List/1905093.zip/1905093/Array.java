import java.util.Arrays;
import java.util.Scanner;

class Array<E> implements list<E> {
    private static int defaultSize = 0;
    private int chunk;
    private int maxSize;
    private int currPosition;
    private int count;
    private E[] listArray;


    Array(int size, int chunk) {
        listArray = (E[]) new Object[chunk];
        maxSize = chunk;
        this.chunk = chunk;
        defaultSize = size;
        count = 0;
        currPosition = 0;
    }

    Array() {
        listArray = (E[]) new Object[0];
        maxSize = chunk;
        this.chunk = chunk;
        defaultSize = 0;
        count = 0;
        currPosition = 0;
    }

    Array(E[] ar, int size, int chunk) {
        listArray = Arrays.copyOf(ar, chunk);
        maxSize = chunk;
        this.chunk = chunk;
        defaultSize = 0;
        count = size;
        currPosition = 0;
    }

    @Override
    public void clear() {
        count = 0;
        currPosition = 0;
    }

    @Override
    public void insert(E x) {

        if (count < maxSize) {
            for (int i = count; i > currPosition; i--) {
                listArray[i] = listArray[i - 1];
            }
            listArray[currPosition] = x;
            count++;
        } else {
            E[] temp = (E[]) new Object[maxSize + chunk];
            maxSize += chunk;

            for (int i = 0; i < currPosition; i++) {
                temp[i] = listArray[i];
            }

            temp[currPosition] = x;
            for (int i = currPosition; i < count; i++) {
                temp[i + 1] = listArray[i];
            }
            listArray = temp;
            count++;
        }
    }


    @Override
    public void append(E x) {

        if (count < maxSize) {
            listArray[count] = x;
            count++;
        } else {
            System.out.println("Insider else");
            E[] temp = (E[]) new Object[maxSize + chunk];
            maxSize = maxSize + chunk;
            for (int i = 0; i < count; i++) {
                temp[i] = listArray[i];
            }
            temp[count] = x;
            listArray = temp;
            count++;
        }
    }


    @Override
    public E remove() {
        E temp = listArray[currPosition];
        if (length() != 0) {

            for (int i = currPosition; i < length() - 1; i++) {
                listArray[i] = listArray[i + 1];
            }
            count--;
            if (currPosition == length()) {
                moveToEnd();
            }

            return temp;
        } else {
            System.out.println("Array is empty");
            return temp;
        }

    }

    @Override
    public void moveToStart() {
        currPosition = 0;
    }

    @Override
    public void moveToEnd() {
        currPosition = length() - 1;
    }

    @Override
    public void prev() {
        if (currPosition == 0) {
            System.out.println("Already at the beginning of the array");
        } else {
            currPosition = currPosition - 1;
        }
    }

    @Override
    public void next() {
        if (currPosition == length() - 1) {
            System.out.println("Cursor already at the ending");
        } else {
            currPosition = currPosition + 1;
        }
    }

    @Override
    public int length() {
        return count;
    }

    @Override
    public int currPos() {
        return currPosition;
    }

    @Override
    public void moveToPos(int x) {
        if (x > length() - 1) {
            System.out.println("Current position exceeds array index");
        } else {
            currPosition = x;
        }
    }

    @Override
    public E getValue() {
        return listArray[currPosition];
    }

    @Override
    public int search(E x) {

        int temp = currPos();
        for (int i = 0; i < length(); i++) {
            ;
            moveToPos(i);
            if (getValue().equals(x)) {
                moveToPos(temp);
                return i;
            }
        }
        return -1;
    }
}
