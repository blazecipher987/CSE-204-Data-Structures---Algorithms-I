import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        //create a BST object
        BST_class<Integer> bst = new BST_class();

        try {
            //Read Input from txt file
            File myObj = new File("D:\\Offline4\\src\\inputs.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                String[] str = data.split(" ");

                System.out.println(str[0] + " " + str[1]);

                if (str[0].equals("F")) {
                    boolean temp = bst.find(Integer.valueOf(str[1]));
                    if(temp) System.out.println("True");
                    else System.out.println("False");
                }

                if (str[0].equals("I")) {
                    bst.insert(Integer.valueOf(str[1]));
                }

                if (str[0].equals("D")) {
                    bst.deleteKey(Integer.valueOf(str[1]));
                }

                if (str[0].equals("T")) {
                    if (str[1].equals("Pre")) {
                        bst.preOrder();
                    } else if (str[1].equals("Post")) {
                        bst.postOrder();
                    } else if (str[1].equals("In")) {
                        bst.inorder();
                    }
                }
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

    }
}