import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


//Node class
class Nodes<E extends Comparable<E>> {
    private E key;
    private Nodes left;
    private Nodes right;

    public Nodes(E data){
        key = data;
        left = right = null;
    }

    public E getKey() {
        return key;
    }

    public void setKey(E key) {
        this.key = key;
    }

    public Nodes getLeft() {
        return left;
    }

    public void setLeft(Nodes left) {
        this.left = left;
    }

    public Nodes getRight() {
        return right;
    }

    public void setRight(Nodes right) {
        this.right = right;
    }
}


//BST class
class BST_class<E extends Comparable<E>> {
    // BST root node 
    private Nodes root;

    BST_class(){
        root = null;
    }

    //delete a node from BST
    void deleteKey(E key) {
        if(find(key)){
            root = delete_Recursive(root, key);
            print();
        }
        else {
            System.out.println("Invalid Operation");
        }

    }
    //recursive delete function
    Nodes delete_Recursive(Nodes root, E key)  {
        //tree is empty
        if (root == null)  return root;

        //traverse the tree
        if (key.compareTo((E) root.getKey()) <0)     //traverse left subtree
            root.setLeft(delete_Recursive(root.getLeft(), key));
        else if (key.compareTo((E) root.getKey()) >0)  //traverse right subtree
            root.setRight(delete_Recursive(root.getRight(), key));
        else  {
            // node contains only one child
            if (root.getLeft() == null)
                return root.getRight();
            else if (root.getRight() == null)
                return root.getLeft();

            // node has two children; 
            //get inorder successor (min value in the right subtree) 
            root.setKey(minValue(root.getRight())) ;

            // Delete the inorder successor 
            root.setRight(delete_Recursive(root.getRight(), (E) root.getKey()));
        }
        return root;
    }
    private E minValue(Nodes root)  {
        //initially minval = root
        E minval = (E) root.getKey();
        //find minval
        while (root.getLeft() != null)  {
            minval = (E) root.getLeft().getKey();
            root = root.getLeft();
        }
        return minval;
    }


    public void insert(E key)  {
        root = insert_Recursive(root, key);
        print();
    }
    //recursive insert function
    private Nodes insert_Recursive(Nodes root, E key) {
        //tree is empty
        if (root == null) {
            root = new Nodes(key);
            return root;
        }
        //traverse the tree
        if (key.compareTo((E) root.getKey())<0)     //insert in the left subtree
            root.setLeft(insert_Recursive(root.getLeft(), key)) ;
        else if (key.compareTo((E) root.getKey())>0)    //insert in the right subtree
            root.setRight(insert_Recursive(root.getRight(), key)) ;
        // return pointer
        return root;
    }


    // method for In-Order traversal of BST
    public void inorder() {
        inorder_Recursive(root);
        System.out.println();
    }
    private void inorder_Recursive(Nodes root) {
        if (root != null) {
            inorder_Recursive(root.getLeft());
            System.out.print(root.getKey() + " ");
            inorder_Recursive(root.getRight());
        }
    }


    //method for Pre-Order traversal in BST
    public void preOrder() {
        preOrder_Recursive(root);
        System.out.println();
    }
    private void preOrder_Recursive(Nodes root) {
        if (root != null) {
            System.out.print(root.getKey() + " ");
            preOrder_Recursive(root.getLeft());
            preOrder_Recursive(root.getRight());
        }
    }


    //method for Post-Order traversal in BST
    public void postOrder() {
        postOrder_Recursive(root);
        System.out.println();
    }
    private void postOrder_Recursive(Nodes root) {
        if (root != null) {
            postOrder_Recursive(root.getLeft());
            postOrder_Recursive(root.getRight());
            System.out.print(root.getKey() + " ");
        }
    }


    public boolean find(E key)  {
        Nodes<E> temp = find_Recursive(root, key);
        if (temp!= null)
            return true;
        else
            return false;
    }
    private Nodes<E> find_Recursive(Nodes<E> root, E key)  {
        // If root is null or key is present at root
        if (root==null ||  key.compareTo((E) root.getKey())==0)
            return root;
        // value is greater than root's key
        if (key.compareTo((E) root.getKey()) <0)
            return find_Recursive(root.getLeft(), key);
        // value is less than root's key
        else
            return find_Recursive(root.getRight(), key);
    }


    public void print(){
        print_recursive(root);
        System.out.println();
    }
    private void print_recursive(Nodes root){

        if(root!=null){
            System.out.print(root.getKey());
            if(root.getLeft()==null && root.getRight()==null){
                return;
            }
            System.out.print("(");
            print_recursive(root.getLeft());
            System.out.print(")");
            System.out.print("(");
            print_recursive(root.getRight());
            System.out.print(")");
        }
    }
}

