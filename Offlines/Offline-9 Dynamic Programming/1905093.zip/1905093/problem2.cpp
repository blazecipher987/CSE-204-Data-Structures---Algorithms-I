#include<iostream>
#include<cstring>
using namespace std;

int dp[10][1<<10]; //For  storing overlapping sequences
int cost[10][10]; //For storing the cost array

int solve(int i, int mask, int n){
    //Base Case,stop when all cities have been visited
    if(i==n){
        return 0;
    }

    //Recall previously stored value in dp array
    if(dp[i][mask]!=-1){
        return dp[i][mask];
    }

    //Calculation for all cities visited before & minimum cost
    int ans =INT_MAX;
    for(int j =0 ; j < n; j++){
        int temp=0;

        //use mask to find out which cities have been visited already and add their cost to temp
        for (int k = 0; k < n; k++)
        {
            if(!(mask&(1<<k))){
                temp+= cost[j][k];
            }
        }

        //basic recursive call
        if(mask&(1<<j))
            ans  = min(ans, cost[j][j] + temp + solve(i+1, (mask^(1<<j)), n ));
        
    }
    return dp[i][mask] = ans;
    
}

int main(){
    int n;
    cin>>n;
    memset(dp, -1 , sizeof(dp));
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cin>>cost[i][j];
        }
    }

    int ans = solve(0,(1<<n)-1 , n);
    cout<<ans;
    
}


/*
3
30 75 95
120 45 20
105 30 90
*/

/*
3
25 100 0
0 25 0
150 100 25
*/

/*
2
100 100
5000 100
*/