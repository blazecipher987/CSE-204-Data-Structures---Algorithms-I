#include <iostream>
#include<string>
#include<cstring>
using namespace std;

string lcsAlgo(string S1, string S2, int m, int n, int &length) {
    int dp[m + 1][n + 1];

//Build table
    for (int i = 0; i <= m; i++) {
        for (int j = 0; j <= n; j++) {
            if (i == 0 || j == 0) //First Row and First coloum filled with 0
                dp[i][j] = 0;

            else if (S1[i - 1] == S2[j - 1]) 
                dp[i][j] = dp[i - 1][j - 1] + 1; //Diagonal Addition
            else
                dp[i][j] = max(dp[i - 1][j], dp[i][j - 1]); //Take greater between the upper or left cell
        }
    }

//Back-tracking
    int index = dp[m][n];
    length = dp[m][n];
    char ans[index + 1]; // +1 to accomodate the end of string
    ans[index] = '\0';
    index--;

    int i = m, j = n; //Starting from the last cell
    while (i > 0 && j > 0) {
    if (S1[i - 1] == S2[j - 1]) { //When match found, include that char in ans
        ans[index] = S1[i - 1];
        i--; //When match found, 
        j--;//go diagonally
        index--;
    }

    else if (dp[i - 1][j] > dp[i][j - 1]) //go left if left cell has bigger value then top cell
      i--;
    else
      j--;
  }
  
  return ans;
}

int main() {
    string s1,s2;
    int length=0;
    cin>>s1;
    cin>>s2;
    string ans ; 

    int m = s1.length();
    int n = s2.length();

  ans = lcsAlgo(s1, s2, m, n, length);
  cout<<length<<endl<<ans<<endl;

}



/*
ABCBDAB
BDCABA
*/

/*
ACCGGTCGAGTGCGCGGAAGCCGGCCGAA
GTCGTTCGGAATGCCGTTGCTCTGTAAA
*/